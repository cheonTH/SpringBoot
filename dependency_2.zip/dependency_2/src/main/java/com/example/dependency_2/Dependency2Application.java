package com.example.dependency_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dependency2Application {

	public static void main(String[] args) {
		SpringApplication.run(Dependency2Application.class, args);
	}

}
