package com.korea.rnBoard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RnBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(RnBoardApplication.class, args);
	}

}
